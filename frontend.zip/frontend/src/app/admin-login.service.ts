import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginService {

  constructor(private http: HttpClient,private router: Router) { }
  adminurl="http://localhost:3000/api/login";
  posturl="http://localhost:3000/api/jobdetail";

  adminlogin(user:any){
    return this.http.post<any>(this.adminurl,user) 
    
  }
  logout() {
    this.router.navigate(['logged']);
  }
  onsave(data:any){
    return this.http.post<any>(this.posturl,data,{})
  }
getjobdetails(){
 return this.http.get<any>("http://localhost:3000/api/jobdetails")
}
delete(id:any){
  console.log(id)
  return this.http.delete<any>("http://localhost:3000/api/jobdetails/"+id)
}


}
