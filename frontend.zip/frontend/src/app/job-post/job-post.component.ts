import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminLoginService } from 'src/app/admin-login.service';

@Component({
  selector: 'app-job-post',
  templateUrl: './job-post.component.html',
  styleUrls: ['./job-post.component.css']
})
export class JobPostComponent implements OnInit {

  error: any;
  errors: any;
  data: any;
  job: boolean=true;
  list: boolean=true;
  constructor(private _auth:AdminLoginService,private FB: FormBuilder,private router: Router) {
    this._auth.getjobdetails().subscribe(
             (data) => {
      
             this.jobdetails = data;
              console.log(this.jobdetails)
      
           });
   }
  postForm=new FormGroup({
    job_title:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
    job_posted_date:new FormControl(['',Validators.required]),
    role:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
    responsibility:new FormControl('',Validators.required),
    company_name:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]), 
    experience:new FormControl('',[Validators.required,Validators.pattern('[0-9]*')]),
    salary_range:new FormControl('',[Validators.required,Validators.pattern('[0-9,]*')]),
    no_of_positions:new FormControl('',[Validators.required,Validators.pattern('[0-9]*')]),
    location:new FormControl('',Validators.required),
    skills_and_qualifications:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
    degree:new FormControl('',Validators.required),
    company_info:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z ]*')]),
    employment_type:new FormControl('',Validators.required),
    industry_type:new FormControl('',Validators.required),
    search_keyword:new FormControl('',Validators.required),
    job_description:new FormControl('',Validators.required),

  })

  ngOnInit(): void {
  }
  get job_title(){
    return this.postForm.get('job_title')
   }
   get job_posted_date(){
    return this.postForm.get('job_posted_date')
   }
   get role(){
    return this.postForm.get('role')
   }
   get  responsibility(){
    return this.postForm.get('responsibility')
   }
   get company_name(){
    return this.postForm.get('company_name')
   }
   get experience(){
    return this.postForm.get('experience')
   }
   get salary_range(){
    return this.postForm.get('salary_range')
   }
  
   get no_of_positions(){
    return this.postForm.get('no_of_positions')
   }
   get location(){
    return this.postForm.get('location')
   }
   get skills_and_qualifications(){
    return this.postForm.get('skills_and_qualifications')
   }
   get degree(){
    return this.postForm.get('degree')
   }
   get company_info(){
    return this.postForm.get('company_info')
   }
   get employment_type(){
    return this.postForm.get('employment_type')
   }
   get industry_type(){
    return this.postForm.get('industry_type')
   }
   get search_keyword(){
    return this.postForm.get('search_keyword')
   }
   get job_description(){
    return this.postForm.get('job_description')
   }
  jobdetails: any = []


  onsave(){
    this._auth.onsave(this.postForm.value).subscribe(
      res =>{
        //console.log(this.postForm.value)
        console.log('FROM SERVER:',res)
        this.error=res
      },
      err=>{ 
      console.log("Error is",err)
      this.errors=err
      }
    )
    }
    get() {
 
      this._auth.getjobdetails().subscribe(
        (data) => {
   
          this.jobdetails = data;
          console.log(this.jobdetails)
   
        });
    }
  oncancel(){
    this.postForm.reset()
  }
  onLogout() {
    this._auth.logout();
  }
  onjobpost(){
    this.job=true;
    this.list=false;
   }
   onjoblist(){
    this.list=true;
    this.job=false;
   }
   ondelete(data: any) {
     console.log(data._id)
     this._auth.delete(data._id).subscribe(
       res => {
         console.log(res)
       }
     )
    window.location.reload()
   }
 
  onedit(data:any)  {
    this.job=true;
    this.list=false;
    this.postForm.controls.job_title.setValue(data.job_title)
    this.postForm.controls.job_posted_date.setValue(data.job_posted_date)
    this.postForm.controls.role.setValue(data.role)
    this.postForm.controls.responsibility.setValue(data.responsibility)
    this.postForm.controls.company_name.setValue(data.company_name)
    this.postForm.controls.experience.setValue(data.experience)
    this.postForm.controls.salary_range.setValue(data.salary_range)
    this.postForm.controls.no_of_positions.setValue(data.no_of_positions)
    this.postForm.controls.location.setValue(data.location)
    this.postForm.controls.skills_and_qualifications.setValue(data.skills_and_qualifications)
    this.postForm.controls.degree.setValue(data.degree)
    this.postForm.controls.company_info.setValue(data.company_info)
    this.postForm.controls.employment_type.setValue(data.employment_type)
    this.postForm.controls.industry_type.setValue(data.industry_type)
    this.postForm.controls.search_keyword.setValue(data.search_keyword)
    this.postForm.controls.job_description.setValue(data.job_description)
    
  }
}
